Use the PointyCloud folder in cuda if you want try cuda version
Use the PointyCloud folder in Master if you want try the classic version